May 2006.

Thank you for dowloading my font, Winob.

Please understand that this font is for personal and/or non-profit use only. You may use
it on websites, t-shirts, etc. ONLY if you do not charge money for them.

Any reproduction, editing, or altering of this font is prohibited. If you have an idea for
an upgrade or a change in theme etc., contact me at dinodude.rex@juno.com.

I require that if you use it on websites, in magazines, books, or some other public places 
that you give me due credit as the author. Put my name on it somewhere.

If you have other questions about this font, or other fonts I made or fonts that I am 
currently working on, email me.(see above^ address)

Seth Martin.